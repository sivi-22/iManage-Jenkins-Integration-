describe('Metro Login Page', () => {    
       it('Should perform login correctly', () => {
        cy.visit(Cypress.env('METRO-URL'))  
        cy.wait(10000)   
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('METRO-PWD'))
        cy.get('#btnLogin').click()
           cy.get('.secondLevel-m').find('a').eq(1).should('have.attr', 'href', '/Metro/training/TrainingCertificate.aspx')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   