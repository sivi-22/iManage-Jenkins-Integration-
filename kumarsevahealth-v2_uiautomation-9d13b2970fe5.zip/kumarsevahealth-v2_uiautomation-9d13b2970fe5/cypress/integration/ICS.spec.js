describe('ICS Login Page', () => {    
       it('Should perform login correctly', () => {
        cy.visit(Cypress.env('ICS-URL'))     
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('ICS-PWD'))
        cy.get('#btnLogin').click()
           cy.get('.secondLevel-m').find('a').should('have.attr', 'href', '/ICS/training/homeTraining.aspx')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   