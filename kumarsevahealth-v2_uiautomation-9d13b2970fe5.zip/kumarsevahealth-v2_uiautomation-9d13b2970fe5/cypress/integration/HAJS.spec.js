describe('HAJS Login Page', () => {    
       it('Should perform login correctly', () => {
        cy.visit(Cypress.env('HAJS-URL'))     
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('HAJS-PWD'))
        cy.get('#btnLogin').click()
           cy.get('a').should('have.attr', 'href', '/hajs/admin/settings.aspx')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   