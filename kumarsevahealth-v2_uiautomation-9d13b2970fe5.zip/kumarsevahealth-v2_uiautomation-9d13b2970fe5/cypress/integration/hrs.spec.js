describe('HRS Login Page', () => {    
       it('Should perform login correctly', () => {
        cy.visit(Cypress.env('HRS-URL'))     
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('HRS-PWD'))
        cy.get('#btnLogin').click()
           cy.get('.secondLevel-m').find('a').should('have.attr', 'href', '/hrs/training/TrainingCertification.aspx')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   