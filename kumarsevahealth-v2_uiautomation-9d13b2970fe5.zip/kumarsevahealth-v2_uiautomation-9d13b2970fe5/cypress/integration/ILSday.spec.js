describe('ILSDay Login Page', () => {    
       it('Should perform login correctly', () => {
        cy.visit(Cypress.env('ILSDAY-URL'))   
        cy.wait(10000)  
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('ILSDAY-PWD'))
        cy.get('#btnLogin').click()
           cy.get('#img1').should('have.attr', 'href', 'home.aspx')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   