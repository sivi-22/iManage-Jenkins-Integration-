describe('CCI Login Page', () => {    
       it('Should perform login correctly', () => {
           cy.visit(Cypress.env('CCI-URL'))     
           cy.get('#txtUserName').type('ramesh.ramakrishnan')
           cy.get('#txtUserPass').type(Cypress.env('CCI-PWD'))
           cy.get('#btnLogin').click()
           cy.get('#headercontrol_Covid19Link').should('contain', 'COVID-19 101')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   