describe('CDS Login Page', () => {    
       it('Should perform login correctly', () => {
           console.log(Cypress.env('CDS-URL'))
        cy.visit(Cypress.env('CDS-URL'))     
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('CDS-PWD'))
        cy.get('#btnLogin').click()
           cy.get('.secondLevel-m').find('a').should('have.attr', 'href', '/cds/training/TrainingCertification.aspx')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   