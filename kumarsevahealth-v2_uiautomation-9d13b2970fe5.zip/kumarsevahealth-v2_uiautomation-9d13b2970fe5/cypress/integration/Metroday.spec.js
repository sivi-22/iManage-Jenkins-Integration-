describe('MetroDay Login Page', () => {    
       it('Should perform login correctly', () => {
        cy.visit(Cypress.env('METRODAY-URL'))     
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('METRODAY-PWD'))
        cy.get('#btnLogin').click()
           
           cy.get('#img1').should('have.attr', 'href', 'wf/wfMain.aspx?O=L')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   