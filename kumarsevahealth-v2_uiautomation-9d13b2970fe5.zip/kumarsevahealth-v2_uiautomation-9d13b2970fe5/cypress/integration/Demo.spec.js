describe('Demo Login Page', () => {    
       it('Should perform login correctly', () => {
        cy.visit(Cypress.env('DEMO-URL'))     
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('DEMO-PWD'))
        cy.get('#btnLogin').click()
           cy.get('.secondLevel-m').find('a').should('have.attr', 'href', '/DEMO/training/TrainingCertification.aspx')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   