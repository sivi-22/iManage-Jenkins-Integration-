describe('Vanmar Login Page', () => {    
       it('Should perform login correctly', () => {
        cy.visit(Cypress.env('VANMAR-URL'))     
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('VANMAR-PWD'))
        cy.get('#btnLogin').click()
           cy.get('.secondLevel-m').find('a').should('have.attr', 'href', '/vanmar/training/TrainingCertification.aspx')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   