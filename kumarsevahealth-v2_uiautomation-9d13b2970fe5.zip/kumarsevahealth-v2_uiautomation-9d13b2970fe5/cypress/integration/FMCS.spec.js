describe('FMCS Login Page', () => {    
       it('Should perform login correctly', () => {
        cy.visit(Cypress.env('FMCS-URL'))     
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('FMCS-PWD'))
        cy.get('#btnLogin').click()
           cy.contains('a', 'COVID-19 101').should('have.attr', 'href', '/fmcs/eLibrary/files/pdf/COVID-19 101.pdf')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
           
          // cy.get('#headercontrol_Covid19Link').should('contain', 'COVID-19 101')
       })
   })
   
   