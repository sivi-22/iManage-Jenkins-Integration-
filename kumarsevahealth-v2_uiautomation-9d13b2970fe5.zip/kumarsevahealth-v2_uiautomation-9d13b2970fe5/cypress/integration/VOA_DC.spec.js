describe('VOA_DC Login Page', () => {    
       it('Should perform login correctly', () => {
        cy.visit(Cypress.env('VAO-DC-URL'))     
        cy.get('#txtUserName').type('ramesh.ramakrishnan')
        cy.get('#txtUserPass').type(Cypress.env('VAO-DC-PWD'))
        cy.get('#btnLogin').click()
           cy.wait(10000)
           cy.get('#img2').should('have.attr', 'href', 'training/homeTraining.aspx')
           cy.get('a').contains('Logout').click({force: true})
           cy.get('td').contains('Thank you for visiting the site.').should('be.visible')
       })
   })
   
   