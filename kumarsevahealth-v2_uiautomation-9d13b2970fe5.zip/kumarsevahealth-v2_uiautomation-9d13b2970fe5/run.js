const execSync = require('child_process').execSync;
var arg = "";
console.log(process.argv)
if(process.argv[2] != undefined){
    arg =  "-- "+process.argv[2]+" "+process.argv[3];
}


//  if(process.argv[2] == undefined && process.argv[4] == undefined){
//     arg = ""; 
// }else if(process.argv[4] != undefined){
//     arg = "";
//     arg =  "-- "+process.argv[2]+" "+process.argv[3]+" "+process.argv[4]+" "+process.argv[5];
// }

try {
    const data =execSync('npm run scripts ' + arg, {stdio:[0, 1, 2]});
    console.log(arg);

    return true;
} catch (error) {
    console.error(`Failed to generate disclaimer: ${error.message}`);
    return false;
}
execSync('npm run posttest', {stdio:[0, 1, 2]});


